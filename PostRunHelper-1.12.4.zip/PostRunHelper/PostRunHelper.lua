-- PostRunHelper 1.12.4
local ADDON_NAME = ...
local PRH = CreateFrame("Frame")
PRH:RegisterEvent("ADDON_LOADED")
PRH:RegisterEvent("CHALLENGE_MODE_COMPLETED")
PRH:RegisterEvent("GROUP_ROSTER_UPDATE")
PRH:RegisterEvent("CHAT_MSG_LOOT")

PostRunHelperDB = PostRunHelperDB or {}

local defaults = { preview=false, scale=1.0, width=760, height=400 }
local function InitDB()
    if type(PostRunHelperDB)~="table" then PostRunHelperDB = {} end
    for k,v in pairs(defaults) do if PostRunHelperDB[k]==nil then PostRunHelperDB[k]=v end end
end

-- utils
local function ClassColor(unit)
    local class = unit and select(2, UnitClass(unit))
    local c = class and RAID_CLASS_COLORS[class]
    if not c then return 1,1,1 end
    return c.r, c.g, c.b
end

local function IsEquipableItemLink(link)
    if not link or type(link)~="string" then return false end
    local itemID = tonumber(link:match("item:(%d+)"))
    if not itemID then return false end
    local classID = select(6, GetItemInfoInstant(itemID))
    return classID == 2 or classID == 4
end

local EDGE_OUTER, EDGE_INNER = 2, 1

local function StripTextures(widget)
    if not widget or not widget.GetNumRegions then return end
    for i=1,(widget:GetNumRegions() or 0) do
        local r = select(i, widget:GetRegions())
        if r and r.GetObjectType and r:GetObjectType()=="Texture" then r:SetTexture(nil); r:Hide() end
    end
end

local function SkinButton(b)
    if not b or b._prhSkinned then return end
    StripTextures(b)
    if not b.SetBackdrop then Mixin(b, BackdropTemplateMixin) end
    b:SetBackdrop({ bgFile="Interface\\Buttons\\WHITE8x8", edgeFile="Interface\\Buttons\\WHITE8x8",
        edgeSize=EDGE_INNER, insets={left=EDGE_INNER,right=EDGE_INNER,top=EDGE_INNER,bottom=EDGE_INNER} })
    b:SetBackdropColor(0.12,0.12,0.16,1)
    b:SetBackdropBorderColor(0,0,0,1)
    b._hover = b._hover or b:CreateTexture(nil,"OVERLAY")
    b._hover:SetAllPoints(true); b._hover:SetColorTexture(1,1,1,0.07); b._hover:Hide()
    b:HookScript("OnEnter", function(self) self._hover:Show() end)
    b:HookScript("OnLeave", function(self) self._hover:Hide() end)
    b:HookScript("OnMouseDown", function(self) self:SetBackdropColor(0.10,0.10,0.14,1) end)
    b:HookScript("OnMouseUp", function(self) self:SetBackdropColor(0.12,0.12,0.16,1) end)
    local fs=b.GetFontString and b:GetFontString(); if fs then fs:SetTextColor(0.95,0.95,0.98) end
    b._prhSkinned=true
end

local function SkinScrollbar(sb)
    if not sb or sb._prhSkinned then return end
    local function apply()
        if sb.ScrollUpButton then sb.ScrollUpButton:Hide() end
        if sb.ScrollDownButton then sb.ScrollDownButton:Hide() end
        if sb.ThumbTexture then sb.ThumbTexture:Hide() end
        StripTextures(sb)
        if not sb._flat then
            local t = sb:CreateTexture(nil,"ARTWORK")
            t:SetColorTexture(0.6,0.8,1,0.85)
            t:SetWidth(4)
            t:SetPoint("TOP", sb, "TOP", 0, -2)
            t:SetPoint("BOTTOM", sb, "BOTTOM", 0, 2)
            sb._flat = t
        end
    end
    apply(); sb:HookScript("OnShow", apply)
    sb._prhSkinned=true
end

local function CreatePanel(parent,w,h)
    local f=CreateFrame("Frame",nil,parent,"BackdropTemplate")
    f:SetSize(w,h)
    f:SetBackdrop({ bgFile="Interface\\Buttons\\WHITE8x8", edgeFile="Interface\\Buttons\\WHITE8x8",
        edgeSize=EDGE_INNER, insets={left=EDGE_INNER,right=EDGE_INNER,top=EDGE_INNER,bottom=EDGE_INNER} })
    f:SetBackdropColor(0.08,0.08,0.1,0.92)
    f:SetBackdropBorderColor(0,0,0,1)
    return f
end

-- slot mapping
local SLOT = {
    INVTYPE_HEAD=1, INVTYPE_NECK=2, INVTYPE_SHOULDER=3, INVTYPE_CHEST=5, INVTYPE_ROBE=5, INVTYPE_WAIST=6, INVTYPE_LEGS=7,
    INVTYPE_FEET=8, INVTYPE_WRIST=9, INVTYPE_HAND=10, INVTYPE_FINGER=11, INVTYPE_TRINKET=13,
    INVTYPE_BACK=15, INVTYPE_CLOAK=15, INVTYPE_TABARD=19, INVTYPE_BODY=4,
    INVTYPE_WEAPONMAINHAND=16, INVTYPE_WEAPONOFFHAND=17, INVTYPE_2HWEAPON=16, INVTYPE_WEAPON=16,
    INVTYPE_SHIELD=17, INVTYPE_HOLDABLE=17, INVTYPE_RANGEDRIGHT=16, INVTYPE_RANGED=16,
}
local function GetItemLevel(link) local lvl=GetDetailedItemLevelInfo and GetDetailedItemLevelInfo(link); if not lvl then lvl=select(4,GetItemInfo(link)) end return lvl end

local function NormalizeName(name) if not name then return nil end return name:gsub("%-.+","") end
local function FindPartyUnitByName(name)
    name = NormalizeName(name)
    if not name then return nil end
    if NormalizeName(UnitName("player")) == name then return "player" end
    for i=1,4 do local u="party"..i; if UnitExists(u) and NormalizeName(UnitName(u))==name then return u end end
    return nil
end

-- ui
local Dialog
local headerFrame, optionsFrame, contentFrame
local previewTicker

local demoNames = { "Cantrelle", "Kordac", "Ariem", "Veluna" }
local demoItems = {188922,190630,190341,201759,193645,190953,193652,173244}

local function StopPreviewTicker() if previewTicker then previewTicker:Cancel(); previewTicker=nil end end
local function ShouldRunDemoLoot() return PostRunHelperDB.preview and not IsInGroup() end

local function AddWhenReady(who, itemID, tries)
    tries = (tries or 0) + 1
    local link = select(2, GetItemInfo(itemID))
    if link then Dialog:AddLoot(who, link); return end
    if tries < 12 then
        if C_Item and C_Item.RequestLoadItemDataByID then C_Item.RequestLoadItemDataByID(itemID) end
        C_Timer.After(0.25, function() AddWhenReady(who, itemID, tries) end)
    end
end

local function StartPreviewTicker()
    StopPreviewTicker()
    if not Dialog or not Dialog:IsShown() or not ShouldRunDemoLoot() then return end
    previewTicker = C_Timer.NewTicker(1.8, function()
        local whoPool = { UnitName("player") or "You", unpack(demoNames) }
        AddWhenReady(whoPool[math.random(#whoPool)], demoItems[math.random(#demoItems)], 0)
    end)
end

local function BuildDialog()
    if Dialog then return Dialog end
    local f = CreateFrame("Frame", "PRH_Dialog", UIParent, "BackdropTemplate")
    f:SetPoint("CENTER")
    f:SetMovable(true); f:EnableMouse(true)
    f:RegisterForDrag("LeftButton"); f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:SetFrameStrata("DIALOG")
    f:SetResizable(true); if f.SetResizeBounds then f:SetResizeBounds(560,300,1400,900) end
    f:SetScale(PostRunHelperDB.scale or 1.0)
    f:SetBackdrop({ bgFile="Interface\\Buttons\\WHITE8x8", edgeFile="Interface\\Buttons\\WHITE8x8", edgeSize=EDGE_OUTER,
        insets={left=EDGE_OUTER,right=EDGE_OUTER,top=EDGE_OUTER,bottom=EDGE_OUTER} })
    f:SetBackdropColor(0.06,0.06,0.08,0.95); f:SetBackdropBorderColor(0,0,0,1)
    local accent=f:CreateTexture(nil,"ARTWORK"); accent:SetColorTexture(0,0.85,0.8,1); accent:SetHeight(3)
    accent:SetPoint("TOPLEFT",EDGE_OUTER,-EDGE_OUTER); accent:SetPoint("TOPRIGHT",-EDGE_OUTER,-EDGE_OUTER)

    headerFrame = CreateFrame("Frame", nil, f, "BackdropTemplate")
    headerFrame:SetBackdrop({ bgFile="Interface\\Buttons\\WHITE8x8", edgeFile="Interface\\Buttons\\WHITE8x8",
        edgeSize=EDGE_INNER, insets={left=EDGE_INNER,right=EDGE_INNER,top=EDGE_INNER,bottom=EDGE_INNER} })
    headerFrame:SetBackdropColor(0.08,0.08,0.1,0.95); headerFrame:SetBackdropBorderColor(0,0,0,1)
    headerFrame:SetPoint("TOPLEFT",12,-34); headerFrame:SetPoint("TOPRIGHT",-12,-34); headerFrame:SetHeight(34)

    local title = f:CreateFontString(nil,"OVERLAY","GameFontNormalLarge"); title:SetPoint("TOPLEFT",12,-10); title:SetText("Post-Run Helper")

    local close = CreateFrame("Button", nil, f); close:SetSize(22,22); close:SetPoint("TOPRIGHT",-6,-6); SkinButton(close); close:SetScript("OnClick", function() f:Hide() end)
    local xfs = close:CreateFontString(nil,"OVERLAY","GameFontNormalLarge"); xfs:SetPoint("CENTER"); xfs:SetText("×"); xfs:SetTextColor(0.95,0.3,0.3)

    local opt = CreateFrame("Button", nil, f); opt:SetSize(22,22); opt:SetPoint("RIGHT", close, "LEFT", -6, 0); SkinButton(opt)
    local ofs = opt:CreateFontString(nil,"OVERLAY","GameFontNormal"); ofs:SetPoint("CENTER"); ofs:SetText("O"); ofs:SetTextColor(0.9,0.95,1)

    -- header buttons
    local btnLeave = CreateFrame("Button", nil, headerFrame, "UIPanelButtonTemplate"); btnLeave:SetSize(140,22); btnLeave:SetPoint("LEFT",8,0)
    btnLeave:SetText("Leave Group"); SkinButton(btnLeave)
    btnLeave:SetScript("OnClick", function() if IsInGroup() then C_PartyInfo.LeaveParty() end f:Hide() end)

    local btnKey = CreateFrame("Button", nil, headerFrame, "UIPanelButtonTemplate"); btnKey:SetSize(70,22); btnKey:SetPoint("LEFT", btnLeave, "RIGHT", 12, 0)
    btnKey:SetText("/key"); SkinButton(btnKey)
    btnKey:RegisterForClicks("AnyUp")
    btnKey:SetScript("OnClick", function() if RunMacroText then RunMacroText("/key") end end)

    -- options
    optionsFrame = CreateFrame("Frame", nil, f, "BackdropTemplate")
    optionsFrame:SetBackdrop({ bgFile="Interface\\Buttons\\WHITE8x8", edgeFile="Interface\\Buttons\\WHITE8x8",
        edgeSize=EDGE_INNER, insets={left=EDGE_INNER,right=EDGE_INNER,top=EDGE_INNER,bottom=EDGE_INNER} })
    optionsFrame:SetBackdropColor(0.08,0.08,0.1,0.95); optionsFrame:SetBackdropBorderColor(0,0,0,1)
    optionsFrame:SetPoint("TOPLEFT",12,-74); optionsFrame:SetPoint("TOPRIGHT",-12,-74); optionsFrame:SetHeight(34); optionsFrame:Hide()

    opt:SetScript("OnClick", function() optionsFrame:SetShown(not optionsFrame:IsShown()); f:Relayout() end)

    local btnPreview = CreateFrame("Button", nil, optionsFrame, "UIPanelButtonTemplate"); btnPreview:SetSize(120,22); btnPreview:SetPoint("LEFT",8,0); SkinButton(btnPreview)
    local function UpdatePreviewLabel() btnPreview:SetText("Preview: "..(PostRunHelperDB.preview and "ON" or "OFF")) end
    btnPreview:SetScript("OnClick", function()
        PostRunHelperDB.preview = not PostRunHelperDB.preview; UpdatePreviewLabel()
        if f:IsShown() then f:RebuildParty(); f:ClearLoot(); if ShouldRunDemoLoot() then StartPreviewTicker() else StopPreviewTicker() end end
    end)
    UpdatePreviewLabel()

    local sMinus = CreateFrame("Button", nil, optionsFrame, "UIPanelButtonTemplate"); sMinus:SetSize(80,22); sMinus:SetPoint("LEFT", btnPreview, "RIGHT", 12, 0); sMinus:SetText("Scale -"); SkinButton(sMinus)
    local sPlus  = CreateFrame("Button", nil, optionsFrame, "UIPanelButtonTemplate"); sPlus:SetSize(80,22);  sPlus:SetPoint("LEFT", sMinus, "RIGHT", 8, 0); sPlus:SetText("Scale +"); SkinButton(sPlus)
    local scaleText = optionsFrame:CreateFontString(nil,"OVERLAY","GameFontHighlight"); scaleText:SetPoint("LEFT", sPlus, "RIGHT", 12, 0)
    local function UpdateScaleLabel() scaleText:SetText(("Scale (%.2f)"):format(PostRunHelperDB.scale or 1.0)) end
    UpdateScaleLabel()
    sMinus:SetScript("OnClick", function() PostRunHelperDB.scale=math.max(0.70,(PostRunHelperDB.scale or 1.0)-0.05); f:SetScale(PostRunHelperDB.scale); UpdateScaleLabel() end)
    sPlus:SetScript("OnClick",  function() PostRunHelperDB.scale=math.min(1.60,(PostRunHelperDB.scale or 1.0)+0.05); f:SetScale(PostRunHelperDB.scale); UpdateScaleLabel() end)

    -- content
    contentFrame = CreateFrame("Frame", nil, f)
    local left = CreatePanel(contentFrame,360,300)
    local right= CreatePanel(contentFrame,360,300)
    local leftLabel = left:CreateFontString(nil,"OVERLAY","GameFontNormal"); leftLabel:SetPoint("TOPLEFT",8,-8); leftLabel:SetText("Party |cffa0a0a0(click to inspect)|r")
    local rightLabel= right:CreateFontString(nil,"OVERLAY","GameFontNormal"); rightLabel:SetPoint("TOPLEFT",8,-8); rightLabel:SetText("Loot (equipable)")

    local leftScroll = CreateFrame("ScrollFrame", nil, left, "UIPanelScrollFrameTemplate")
    leftScroll:SetPoint("TOPLEFT", 8, -28); leftScroll:SetPoint("BOTTOMRIGHT", -24, 10)
    local leftContent = CreateFrame("Frame", nil, leftScroll); leftContent:SetSize(1,1); leftScroll:SetScrollChild(leftContent)
    SkinScrollbar(leftScroll.ScrollBar or _G[leftScroll:GetName().."ScrollBar"])

    local rightScroll = CreateFrame("ScrollFrame", nil, right, "UIPanelScrollFrameTemplate")
    rightScroll:SetPoint("TOPLEFT", 8, -28); rightScroll:SetPoint("BOTTOMRIGHT", -24, 10)
    local rightContent = CreateFrame("Frame", nil, rightScroll); rightContent:SetSize(1,1); rightScroll:SetScrollChild(rightContent)
    SkinScrollbar(rightScroll.ScrollBar or _G[rightScroll:GetName().."ScrollBar"])

    -- sizers
    local function EdgeSizer(sizing)
        local s = CreateFrame("Frame", nil, f); s:EnableMouse(true)
        if sizing=="LEFT" then s:SetPoint("TOPLEFT", 0, -40); s:SetPoint("BOTTOMLEFT", 0, 0); s:SetWidth(6)
        elseif sizing=="RIGHT" then s:SetPoint("TOPRIGHT", 0, -40); s:SetPoint("BOTTOMRIGHT", 0, 0); s:SetWidth(6)
        elseif sizing=="TOP" then s:SetPoint("TOPLEFT", 0, -32); s:SetPoint("TOPRIGHT", 0, -32); s:SetHeight(6)
        elseif sizing=="BOTTOM" then s:SetPoint("BOTTOMLEFT", 0, 0); s:SetPoint("BOTTOMRIGHT", 0, 0); s:SetHeight(6) end
        local hl = s:CreateTexture(nil,"OVERLAY"); hl:SetAllPoints(true); hl:SetColorTexture(0.6,0.8,1,0.20); hl:Hide()
        s:SetScript("OnEnter", function() SetCursor("Interface\\CURSOR\\POINT"); hl:Show() end)
        s:SetScript("OnLeave", function() ResetCursor(); hl:Hide() end)
        s:SetScript("OnMouseDown", function() f:StartSizing(sizing) end)
        s:SetScript("OnMouseUp", function() f:StopMovingOrSizing(); PostRunHelperDB.width, PostRunHelperDB.height = f:GetSize(); f:Relayout() end)
    end
    EdgeSizer("LEFT"); EdgeSizer("RIGHT"); EdgeSizer("TOP"); EdgeSizer("BOTTOM")

    function f:Relayout()
        local W = PostRunHelperDB.width or defaults.width
        local H = PostRunHelperDB.height or defaults.height
        f:SetSize(W,H)
        headerFrame:ClearAllPoints(); headerFrame:SetPoint("TOPLEFT",12,-34); headerFrame:SetPoint("TOPRIGHT",-12,-34)
        optionsFrame:ClearAllPoints(); optionsFrame:SetPoint("TOPLEFT",12,-74); optionsFrame:SetPoint("TOPRIGHT",-12,-74)
        contentFrame:ClearAllPoints()
        if optionsFrame:IsShown() then
            contentFrame:SetPoint("TOPLEFT",12,-112); contentFrame:SetPoint("TOPRIGHT",-12,-112)
        else
            contentFrame:SetPoint("TOPLEFT",12,-72); contentFrame:SetPoint("TOPRIGHT",-12,-72)
        end
        contentFrame:SetPoint("BOTTOMLEFT",12,12); contentFrame:SetPoint("BOTTOMRIGHT",-12,12)
        local innerW = contentFrame:GetWidth() or (W-24)
        local gap=16
        local panelW = math.floor((innerW-gap)/2)
        left:SetSize(panelW, contentFrame:GetHeight()); right:SetSize(panelW, contentFrame:GetHeight())
        left:ClearAllPoints(); right:ClearAllPoints()
        left:SetPoint("TOPLEFT", contentFrame, "TOPLEFT", 0, 0)
        right:SetPoint("TOPRIGHT", contentFrame, "TOPRIGHT", 0, 0)
    end

    -- party
    f.partyButtons = {}
    function f:ClearParty() for _,b in ipairs(self.partyButtons) do b:Hide() end wipe(self.partyButtons); leftContent:SetSize(1,1) end

    local function addPartyButton(parent, unit, isDemo, displayName)
        local btn = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
        btn:SetSize(260,22)
        local nm = displayName or (isDemo and unit or UnitName(unit))
        btn:SetText(nm or unit); SkinButton(btn)
        local function colorize()
            local r,g,b = 0.85,0.85,0.88; if not isDemo then r,g,b = ClassColor(unit) end
            local fs = btn:GetFontString(); if fs then fs:SetTextColor(r,g,b) end
        end
        btn:HookScript("OnShow", colorize); btn:HookScript("OnEnable", colorize); colorize()
        if not isDemo then
            btn:RegisterForClicks("AnyUp")
            btn:SetScript("OnClick", function(selfBtn, btnName)
                if btnName=="RightButton" then
                    local name = UnitName(unit); if name then ChatFrame_OpenChat("/w "..name.." ", SELECTED_DOCK_FRAME) end
                elseif btnName=="MiddleButton" then
                    InitiateTrade(unit)
                else
                    if unit=="player" then ToggleCharacter("PaperDollFrame")
                    else if not InspectFrame then InspectFrame_LoadUI() end; if InspectUnit then InspectUnit(unit) else ShowUIPanel(InspectFrame) end end
                end
            end)
        else
            btn:Disable()
        end
        return btn
    end

    function f:RebuildParty()
        self:ClearParty()
        local y=-2
        local function place(btn) btn:ClearAllPoints(); btn:SetPoint("TOPLEFT", 0, y); y=y-26; table.insert(self.partyButtons, btn) end
        if IsInGroup() then
            place(addPartyButton(leftContent, "player", false))
            for i=1,4 do if UnitExists("party"..i) then place(addPartyButton(leftContent, "party"..i, false)) end end
        else
            place(addPartyButton(leftContent, "player", false))
            if PostRunHelperDB.preview then for i=1,4 do place(addPartyButton(leftContent, "party"..i, true, "Demo Member "..i)) end end
        end
        leftContent:SetSize(260, math.max(1, -y + 6))
    end

    -- loot
    f.lootRows = {}
    function f:ClearLoot() for _,r in ipairs(self.lootRows) do r:Hide() end wipe(self.lootRows); rightContent:SetSize(1,1) end

    local function EquippedComparison(unit, lootedLink)
        local _,_,_,_,_,_,_,equipLoc = GetItemInfoInstant(lootedLink); if not equipLoc then return end
        local function lowest(slots) local L,lv; for _,s in ipairs(slots) do local l=GetInventoryItemLink(unit,s); local il=GetItemLevel(l); if l and (not lv or (il and il<lv)) then L,lv=l,il end end return L,lv end
        if equipLoc=="INVTYPE_FINGER" then return lowest({11,12})
        elseif equipLoc=="INVTYPE_TRINKET" then return lowest({13,14})
        elseif equipLoc=="INVTYPE_WEAPON" or equipLoc=="INVTYPE_WEAPONMAINHAND" or equipLoc=="INVTYPE_WEAPONOFFHAND" or equipLoc=="INVTYPE_SHIELD" or equipLoc=="INVTYPE_HOLDABLE" then
            return lowest({16,17})
        elseif equipLoc=="INVTYPE_2HWEAPON" or equipLoc=="INVTYPE_RANGED" or equipLoc=="INVTYPE_RANGEDRIGHT" then
            local l = GetInventoryItemLink(unit,16); return l, GetItemLevel(l)
        else
            local slot = SLOT[equipLoc]; if not slot then return end
            local l = GetInventoryItemLink(unit,slot); return l, GetItemLevel(l)
        end
    end

    function f:AddLoot(playerName, lootedLink)
        local y = -2 - (#self.lootRows)*22
        local row = CreateFrame("Button", nil, rightContent); row:SetSize(600,20); row:SetPoint("TOPLEFT",0,y); row:SetMotionScriptsWhileDisabled(true); row:EnableMouse(true)
        local who = tostring(playerName or "?")
        local unit = FindPartyUnitByName(who)
        local lootedLvl = GetItemLevel(lootedLink)
        local equippedLink, equippedLvl = nil, nil
        if unit then local L,lv = EquippedComparison(unit, lootedLink); equippedLink, equippedLvl = L, lv end
        local deltaText = ""
        if lootedLvl and equippedLvl then local d=lootedLvl-equippedLvl; local sign=(d>0 and "+") or ""; local color=(d>0 and "|cff3aff3a") or (d<0 and "|cffff3a3a") or "|cffffffff"; deltaText=(" %s(%s%d ilvl)|r"):format(color,sign,d) end
        local fs = row:CreateFontString(nil,"OVERLAY","GameFontHighlight"); fs:SetPoint("LEFT",0,0); fs:SetWidth(600); fs:SetJustifyH("LEFT")
        if equippedLink then fs:SetText(string.format("|cffffffff%s|r: %s  |cffaaaaaa→|r  %s%s", who, lootedLink, equippedLink, deltaText))
        else fs:SetText(string.format("|cffffffff%s|r: %s", who, lootedLink)) end
        row:SetScript("OnEnter", function(selfBtn) GameTooltip:SetOwner(selfBtn,"ANCHOR_CURSOR_RIGHT"); if lootedLink then GameTooltip:SetHyperlink(lootedLink) end; if equippedLink then GameTooltip:AddLine(" "); GameTooltip:AddLine("Equipped:",1,1,1); GameTooltip:AddLine(equippedLink,0.8,0.8,1,true) end; GameTooltip:Show() end)
        row:SetScript("OnLeave", function() GameTooltip:Hide() end)
        table.insert(self.lootRows, row); rightContent:SetSize(260, math.max(1, -y + 24))
    end

    f:SetScript("OnShow", function(self) self:Relayout(); self:RebuildParty(); self:ClearLoot(); if ShouldRunDemoLoot() then StartPreviewTicker() end end)
    f:SetScript("OnHide", function() StopPreviewTicker() end)

    Dialog = f
    f:SetSize(PostRunHelperDB.width or defaults.width, PostRunHelperDB.height or defaults.height)
    f:Relayout()
    return f
end

local function ShowDialog() local f=BuildDialog(); f:Show() end

-- loot parsing
local function ExtractLoot(msg, author)
    local link = msg:match("|Hitem:.-|h%[.-%]|h"); if not link then return end
    if not IsEquipableItemLink(link) then return end
    local who = msg:match("^(.-) receives loot: "); if who then return who, link end
    local youPhrases = {ERR_YOU_LOOTED_S, "You receive loot:"}
    for _,p in ipairs(youPhrases) do if p then local plain=p:gsub("%%s",""); if msg:find(plain,1,true) then return UnitName("player"), link end end end
    if author then return author, link end
end

-- events
function PRH:ADDON_LOADED(name)
    if name~=ADDON_NAME then return end
    InitDB()
    SLASH_POSTRUNHELPER1="/prh"
    SlashCmdList["POSTRUNHELPER"]=function(msg) msg=(msg or ""):lower(); if msg=="hide" then if Dialog and Dialog:IsShown() then Dialog:Hide() end else ShowDialog() end end
end

function PRH:CHALLENGE_MODE_COMPLETED() ShowDialog() end

function PRH:GROUP_ROSTER_UPDATE()
    if Dialog and Dialog:IsShown() then
        Dialog:RebuildParty()
        if ShouldRunDemoLoot() then StartPreviewTicker() else StopPreviewTicker() end
    end
end

function PRH:CHAT_MSG_LOOT(msg, author)
    if Dialog and Dialog:IsShown() then local p,l = ExtractLoot(msg,author); if p and l then Dialog:AddLoot(p,l) end end
end

PRH:SetScript("OnEvent", function(self,event,...) if self[event] then self[event](self, ...) end end)

-- EOF
